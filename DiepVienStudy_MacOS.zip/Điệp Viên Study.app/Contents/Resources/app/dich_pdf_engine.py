#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ĐỘNG CƠ DỊCH PDF GIỮ NGUYÊN BỐ CỤC ĐỘC LẬP CHO ĐIỆP VIÊN STUDY (WINDOWS & MACOS)
Hỗ trợ chạy độc lập 100% trên cả MacBook/iMac và Windows thông qua PyMuPDF (fitz).
"""

import os
import re
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import requests

BASE_DIR = Path(__file__).resolve().parent


def _translate_text_google(text: str, lang_in: str = "auto", lang_out: str = "vi") -> str:
    t = (text or "").strip()
    if not t or len(t) < 2:
        return t
    # Bỏ qua công thức toán thuần số/ký hiệu
    if not re.search(r"[a-zA-Z\u4e00-\u9fff]", t):
        return t
    try:
        url = (
            "https://translate.googleapis.com/translate_a/single?client=gtx"
            f"&sl={urllib.parse.quote(lang_in)}&tl={urllib.parse.quote(lang_out)}&dt=t&q={urllib.parse.quote(t)}"
        )
        r = requests.get(url, timeout=8)
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, list) and data and isinstance(data[0], list):
                return "".join(seg[0] for seg in data[0] if seg and seg[0]).strip() or t
    except Exception:
        pass
    return t


def translate_pdf_preserve_layout(
    pdf_path: str,
    service: str = "google",
    lang_in: str = "auto",
    lang_out: str = "vi",
    threads: int = 4,
    output_dir: str | None = None,
) -> dict:
    started = time.time()
    src = Path(pdf_path).expanduser().resolve()
    if not src.is_file():
        raise FileNotFoundError(f"Không tìm thấy file PDF: {src}")

    out_dir = Path(output_dir) if output_dir else (src.parent / "PDF_Da_Dich_DiepVienStudy")
    out_dir.mkdir(parents=True, exist_ok=True)

    # Thử dùng bộ VI-Translate đầy đủ nếu có trên máy
    ext_candidates = [
        Path(r"C:\Users\Admin\Downloads\02. Điệp Viên Tài Liệu\Tool_Dich_PDF_Chuan_Bo_Cuc"),
        BASE_DIR.parent.parent / "03_He_Sinh_Thai_8_Tool" / "02_Diep_Vien_Tai_Lieu" / "Tool_Dich_PDF_Chuan_Bo_Cuc",
    ]
    for cand in ext_candidates:
        if (cand / "scripts" / "translate_pdf.py").is_file():
            try:
                import sys
                if str(cand) not in sys.path:
                    sys.path.insert(0, str(cand))
                from scripts.translate_pdf import translate_pdf
                res = translate_pdf(
                    input_pdf=src,
                    output_dir=out_dir,
                    target_language=lang_out,
                    source_language=lang_in,
                    threads=max(1, min(8, int(threads or 4))),
                    overwrite=True,
                    engine="google",
                    ocr="off",
                    bilingual="side-by-side",
                )
                mono_p = str(res.path.resolve()) if res.path else ""
                dual_p = str(res.bilingual.resolve()) if res.bilingual else ""
                elapsed = round(time.time() - started, 2)
                return {
                    "ok": True,
                    "mono_pdf": mono_p,
                    "dual_pdf": dual_p,
                    "mono_path": mono_p,
                    "dual_path": dual_p,
                    "output_dir": str(out_dir),
                    "elapsed_seconds": elapsed,
                }
            except Exception:
                pass

    # Nhánh độc lập đa nền tảng (macOS / Windows) dùng PyMuPDF trực tiếp
    import pymupdf as fitz

    doc_src = fitz.open(str(src))
    doc_mono = fitz.open(str(src))

    # Tìm font hỗ trợ Tiếng Việt trên macOS hoặc Windows
    font_candidates = [
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "/Library/Fonts/Arial.ttf",
        r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\segoeui.ttf",
    ]
    vn_font_file = next((f for f in font_candidates if os.path.isfile(f)), None)

    for page_idx in range(len(doc_mono)):
        page = doc_mono[page_idx]
        blocks = page.get_text("blocks")
        text_blocks = [
            b for b in blocks
            if len(b) >= 7 and b[6] == 0 and (b[4] or "").strip() and len((b[4] or "").strip()) >= 3
        ]
        if not text_blocks:
            continue

        raw_texts = [re.sub(r"\s+", " ", b[4].strip()) for b in text_blocks]
        with ThreadPoolExecutor(max_workers=max(1, min(8, int(threads or 4)))) as ex:
            translated_texts = list(ex.map(lambda t: _translate_text_google(t, lang_in, lang_out), raw_texts))

        for b, tr_txt in zip(text_blocks, translated_texts):
            if not tr_txt or tr_txt == b[4].strip():
                continue
            rect = fitz.Rect(b[0], b[1], b[2], b[3])
            page.draw_rect(rect, color=(1, 1, 1), fill=(1, 1, 1))
            fsize = max(7.5, min(11.5, rect.height / max(1.5, (len(tr_txt) / max(12.0, rect.width / 5.2)))))
            try:
                page.insert_textbox(
                    rect,
                    tr_txt,
                    fontsize=fsize,
                    fontname="helv" if not vn_font_file else "F0",
                    fontfile=vn_font_file,
                    color=(0.08, 0.1, 0.15),
                )
            except Exception:
                page.insert_textbox(rect, tr_txt, fontsize=8.5, color=(0.08, 0.1, 0.15))

    mono_out = out_dir / f"{src.stem}-{lang_out}.pdf"
    doc_mono.save(str(mono_out), garbage=3, deflate=True)

    # Tạo bản Song Ngữ (Side-by-Side 2 trang cạnh nhau)
    dual_out = out_dir / f"{src.stem}-{lang_out}-dual.pdf"
    doc_dual = fitz.open()
    for i in range(len(doc_src)):
        r_orig = doc_src[i].rect
        w, h = r_orig.width, r_orig.height
        new_p = doc_dual.new_page(width=w * 2, height=h)
        new_p.show_pdf_page(fitz.Rect(0, 0, w, h), doc_src, i)
        new_p.show_pdf_page(fitz.Rect(w, 0, w * 2, h), doc_mono, i)
    doc_dual.save(str(dual_out), garbage=3, deflate=True)

    doc_src.close()
    doc_mono.close()
    doc_dual.close()

    elapsed = round(time.time() - started, 2)
    return {
        "ok": True,
        "mono_pdf": str(mono_out),
        "dual_pdf": str(dual_out),
        "mono_path": str(mono_out),
        "dual_path": str(dual_out),
        "output_dir": str(out_dir),
        "elapsed_seconds": elapsed,
    }


def convert_pdf_to_word(
    pdf_path: str,
    translate_to_vi: bool = False,
    include_images: bool = True,
    output_dir: str | None = None,
) -> dict:
    """
    Chuyển đổi file PDF sang file Word (.docx) chuẩn định dạng Times New Roman 13pt,
    bảo toàn cấu trúc tiêu đề, đoạn văn, công thức và hình ảnh minh họa.
    """
    import io
    import pymupdf as fitz
    from docx import Document
    from docx.shared import Pt, Inches, RGBColor
    from docx.oxml.ns import qn

    started = time.time()
    src = Path(pdf_path).expanduser().resolve()
    if not src.is_file():
        raise FileNotFoundError(f"Không tìm thấy file PDF: {src}")

    out_dir = Path(output_dir) if output_dir else (src.parent / "Word_Tu_PDF_DiepVienStudy")
    out_dir.mkdir(parents=True, exist_ok=True)

    pdf_doc = fitz.open(str(src))
    word_doc = Document()

    # Thiết lập chuẩn font Times New Roman 13pt chữ đen tuyền
    normal_style = word_doc.styles["Normal"]
    normal_style.font.name = "Times New Roman"
    normal_style.font.size = Pt(13)
    normal_style.font.color.rgb = RGBColor(0, 0, 0)
    try:
        normal_style._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    except Exception:
        pass

    total_pages = len(pdf_doc)
    for page_idx in range(total_pages):
        page = pdf_doc[page_idx]
        p_dict = page.get_text("dict")
        blocks = p_dict.get("blocks", []) if isinstance(p_dict, dict) else []

        # Phát hiện bảng biểu trên trang bằng PyMuPDF find_tables()
        table_bboxes = []
        page_items = []
        try:
            tf = page.find_tables()
            for tab in (tf.tables if tf and hasattr(tf, "tables") else []):
                rows_data = tab.extract()
                if rows_data and len(rows_data) >= 1 and any(any(cell for cell in r) for r in rows_data):
                    tb = tab.bbox  # (x0, y0, x1, y1)
                    table_bboxes.append(tb)
                    page_items.append({
                        "kind": "table",
                        "y0": float(tb[1]),
                        "x0": float(tb[0]),
                        "rows": [[re.sub(r"\s+", " ", (c or "").strip()) for c in r] for r in rows_data],
                    })
        except Exception:
            pass

        def _inside_any_table(bbox):
            if not bbox or len(bbox) < 4 or not table_bboxes:
                return False
            cx = (float(bbox[0]) + float(bbox[2])) / 2.0
            cy = (float(bbox[1]) + float(bbox[3])) / 2.0
            for tb in table_bboxes:
                if (tb[0] - 4) <= cx <= (tb[2] + 4) and (tb[1] - 4) <= cy <= (tb[3] + 4):
                    return True
            return False

        has_any_text = len(page_items) > 0

        for b in blocks:
            b_type = b.get("type", 0)
            b_bbox = b.get("bbox", (0, 0, 0, 0))
            y0 = float(b_bbox[1]) if len(b_bbox) >= 2 else 0.0
            x0 = float(b_bbox[0]) if len(b_bbox) >= 1 else 0.0
            if b_type == 0:
                if _inside_any_table(b_bbox):
                    continue
                lines_txt = []
                max_size = 11.0
                is_bold = False
                for line in b.get("lines", []):
                    spans_txt = []
                    for sp in line.get("spans", []):
                        st = (sp.get("text") or "").strip()
                        if st:
                            spans_txt.append(st)
                            sz = float(sp.get("size") or 11.0)
                            if sz > max_size:
                                max_size = sz
                            flags = int(sp.get("flags") or 0)
                            fn_low = str(sp.get("font") or "").lower()
                            if (flags & 16) or "bold" in fn_low or "medi" in fn_low:
                                is_bold = True
                    if spans_txt:
                        lines_txt.append(" ".join(spans_txt))
                para_text = re.sub(r"\s+", " ", " ".join(lines_txt)).strip()
                if para_text:
                    has_any_text = True
                    page_items.append({
                        "kind": "text",
                        "y0": y0,
                        "x0": x0,
                        "text": para_text,
                        "size": max_size,
                        "bold": is_bold,
                    })
            elif b_type == 1 and include_images:
                img_bytes = b.get("image")
                if img_bytes and len(img_bytes) > 800:
                    w_pt = max(1.0, float(b.get("width") or 200.0))
                    page_items.append({
                        "kind": "image",
                        "y0": y0,
                        "x0": x0,
                        "bytes": img_bytes,
                        "width_inches": min(5.8, max(1.4, w_pt / 96.0)),
                    })

        page_items.sort(key=lambda item: (round(item.get("y0", 0.0), 1), round(item.get("x0", 0.0), 1)))

        if translate_to_vi and page_items:
            only_texts = [it["text"] for it in page_items if it["kind"] == "text"]
            if only_texts:
                with ThreadPoolExecutor(max_workers=4) as ex:
                    tr_list = list(ex.map(lambda t: _translate_text_google(t, "auto", "vi"), only_texts))
                tr_iter = iter(tr_list)
                for it in page_items:
                    if it["kind"] == "text":
                        it["text"] = next(tr_iter, it["text"])

        for it in page_items:
            if it["kind"] == "text":
                p = word_doc.add_paragraph()
                p.paragraph_format.space_after = Pt(6)
                p.paragraph_format.line_spacing = 1.25
                safe_txt = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", str(it["text"] or ""))
                run = p.add_run(safe_txt)
                run.font.name = "Times New Roman"
                run.font.color.rgb = RGBColor(0, 0, 0)
                if it["size"] >= 15.0:
                    run.bold = True
                    run.font.size = Pt(15)
                elif it["size"] >= 13.0 or it["bold"]:
                    run.bold = True
                    run.font.size = Pt(13.5)
                else:
                    run.font.size = Pt(13)
            elif it["kind"] == "table":
                rows_2d = it.get("rows") or []
                num_cols = max((len(r) for r in rows_2d), default=0)
                if rows_2d and num_cols > 0:
                    tbl = word_doc.add_table(rows=len(rows_2d), cols=num_cols)
                    try:
                        tbl.style = "Table Grid"
                    except Exception:
                        pass
                    for r_i, r_vals in enumerate(rows_2d):
                        for c_i in range(num_cols):
                            cell_txt = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", str(r_vals[c_i] if c_i < len(r_vals) else ""))
                            cell = tbl.cell(r_i, c_i)
                            cell.text = ""
                            cp = cell.paragraphs[0]
                            cp.paragraph_format.space_after = Pt(2)
                            crun = cp.add_run(cell_txt)
                            crun.font.name = "Times New Roman"
                            crun.font.size = Pt(12)
                            crun.font.color.rgb = RGBColor(0, 0, 0)
                            if r_i == 0:
                                crun.bold = True
                    word_doc.add_paragraph()
            elif it["kind"] == "image":
                try:
                    word_doc.add_picture(io.BytesIO(it["bytes"]), width=Inches(it["width_inches"]))
                except Exception:
                    pass

        # Nếu trang PDF là bản scan thuần ảnh không có text layer -> chèn ảnh trang sắc nét vào Word
        if not has_any_text and include_images:
            try:
                pix = page.get_pixmap(dpi=160)
                word_doc.add_picture(io.BytesIO(pix.tobytes("png")), width=Inches(6.0))
            except Exception:
                pass

        if page_idx < total_pages - 1:
            word_doc.add_page_break()

    pdf_doc.close()
    suffix = "-vi.docx" if translate_to_vi else ".docx"
    docx_out = out_dir / f"{src.stem}{suffix}"
    word_doc.save(str(docx_out))

    elapsed = round(time.time() - started, 2)
    return {
        "ok": True,
        "docx_path": str(docx_out),
        "pages_count": total_pages,
        "output_dir": str(out_dir),
        "elapsed_seconds": elapsed,
    }

