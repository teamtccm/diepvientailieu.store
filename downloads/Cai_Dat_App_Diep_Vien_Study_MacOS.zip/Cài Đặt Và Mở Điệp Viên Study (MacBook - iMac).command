#!/bin/bash
# ==============================================================================
# 🚀 BỘ CÀI ĐẶT & MỞ 1-CLICK 'ĐIỆP VIÊN STUDY' CHO MACOS (APPLE SILICON & INTEL)
# ==============================================================================
clear
echo "=============================================================================="
echo "  🕵️‍♂️ ĐIỆP VIÊN STUDY — BỘ CÀI ĐẶT 1-CLICK CHO MACOS (MACBOOK / IMAC)"
echo "=============================================================================="
echo ""

export LANG="en_US.UTF-8"
export LC_ALL="en_US.UTF-8"
export PYTHONUTF8=1
export PATH="/opt/homebrew/bin:/usr/local/bin:/Library/Frameworks/Python.framework/Versions/Current/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_SUPPORT_DIR="$HOME/Library/Application Support/DiepVienStudy"
RUNTIME_APP_DIR="$APP_SUPPORT_DIR/app"
VENV_DIR="$APP_SUPPORT_DIR/.venv_mac"
LOCAL_BIN_DIR="$APP_SUPPORT_DIR/bin"

mkdir -p "$APP_SUPPORT_DIR" "$RUNTIME_APP_DIR" "$RUNTIME_APP_DIR/data" "$LOCAL_BIN_DIR"
export PATH="$LOCAL_BIN_DIR:$PATH"

echo "👉 [1/5] Gỡ khóa bảo mật Gatekeeper (xattr) cho bộ ứng dụng..."
xattr -cr "$SCRIPT_DIR" 2>/dev/null || true
chmod +x "$SCRIPT_DIR/Điệp Viên Study.app/Contents/MacOS/DiepVienStudy" 2>/dev/null || true

echo "👉 [2/5] Kiểm tra Python 3 trên macOS..."
find_system_python() {
    for candidate in \
        "/opt/homebrew/bin/python3" \
        "/usr/local/bin/python3" \
        "/Library/Frameworks/Python.framework/Versions/Current/bin/python3" \
        "/usr/bin/python3"; do
        if [ -x "$candidate" ]; then
            if "$candidate" -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >/dev/null 2>&1; then
                echo "$candidate"
                return 0
            fi
        fi
    done
    return 1
}

SYS_PY="$(find_system_python)"
if [ -z "$SYS_PY" ]; then
    echo "   ⚠️ Chưa có Python 3.9+. Đang tự động tải và cài đặt Python 3 chính thức cho macOS..."
    if command -v brew >/dev/null 2>&1; then
        brew install python
    else
        TMP_PKG="$(mktemp -d)/python_macos.pkg"
        curl -L "https://www.python.org/ftp/python/3.12.8/python-3.12.8-macos11.pkg" -o "$TMP_PKG"
        echo "   🔐 Vui lòng nhập mật khẩu máy Mac (nếu được hỏi) để cài Python 3:"
        sudo installer -pkg "$TMP_PKG" -target /
        rm -f "$TMP_PKG"
    fi
    SYS_PY="$(find_system_python)"
fi

if [ -z "$SYS_PY" ]; then
    echo "❌ Không tìm thấy Python 3. Vui lòng cài đặt Python tại https://www.python.org rồi chạy lại file này."
    read -p "Nhấn Enter để đóng..."
    exit 1
fi
echo "   ✅ Đã tìm thấy Python: $($SYS_PY --version)"

echo "👉 [3/5] Cài đặt thư viện AI, Âm thanh CoreAudio, Giao diện & Dịch PDF..."
if [ ! -x "$VENV_DIR/bin/python3" ]; then
    "$SYS_PY" -m venv "$VENV_DIR"
fi
"$VENV_DIR/bin/pip" install --upgrade pip wheel setuptools --quiet
"$VENV_DIR/bin/pip" install \
    pywebview \
    pyobjc-framework-Cocoa \
    pyobjc-framework-WebKit \
    pyobjc-framework-Quartz \
    requests \
    numpy \
    sounddevice \
    edge-tts \
    yt-dlp \
    pymupdf \
    Pillow

echo "👉 [4/5] Kiểm tra bộ xử lý âm thanh FFmpeg / FFprobe..."
if command -v ffmpeg >/dev/null 2>&1 && command -v ffprobe >/dev/null 2>&1; then
    echo "   ✅ Đã có sẵn FFmpeg trên hệ thống."
elif [ -x "$LOCAL_BIN_DIR/ffmpeg" ] && [ -x "$LOCAL_BIN_DIR/ffprobe" ]; then
    echo "   ✅ Đã có sẵn FFmpeg trong bộ ứng dụng."
else
    if command -v brew >/dev/null 2>&1; then
        echo "   ⏳ Đang cài đặt FFmpeg qua Homebrew..."
        brew install ffmpeg
    else
        echo "   ⏳ Đang tải FFmpeg & FFprobe bản độc lập cho macOS..."
        TMP_FF="$(mktemp -d)"
        curl -L "https://evermeet.cx/ffmpeg/getrelease/ffmpeg/zip" -o "$TMP_FF/ffmpeg.zip" && unzip -q -o "$TMP_FF/ffmpeg.zip" -d "$LOCAL_BIN_DIR"
        curl -L "https://evermeet.cx/ffmpeg/getrelease/ffprobe/zip" -o "$TMP_FF/ffprobe.zip" && unzip -q -o "$TMP_FF/ffprobe.zip" -d "$LOCAL_BIN_DIR"
        chmod +x "$LOCAL_BIN_DIR/ffmpeg" "$LOCAL_BIN_DIR/ffprobe" 2>/dev/null || true
        xattr -cr "$LOCAL_BIN_DIR/ffmpeg" "$LOCAL_BIN_DIR/ffprobe" 2>/dev/null || true
        rm -rf "$TMP_FF"
    fi
fi

echo "👉 [5/5] Cài đặt 'Điệp Viên Study.app' vào /Applications và Màn hình chính (Desktop)..."
if [ -d "$SCRIPT_DIR/Điệp Viên Study.app" ]; then
    rm -rf "/Applications/Điệp Viên Study.app" 2>/dev/null || true
    cp -Rf "$SCRIPT_DIR/Điệp Viên Study.app" "/Applications/Điệp Viên Study.app" 2>/dev/null || true
    xattr -cr "/Applications/Điệp Viên Study.app" 2>/dev/null || true
    chmod +x "/Applications/Điệp Viên Study.app/Contents/MacOS/DiepVienStudy" 2>/dev/null || true

    rm -rf "$HOME/Desktop/Điệp Viên Study.app" 2>/dev/null || true
    cp -Rf "$SCRIPT_DIR/Điệp Viên Study.app" "$HOME/Desktop/Điệp Viên Study.app" 2>/dev/null || true
    xattr -cr "$HOME/Desktop/Điệp Viên Study.app" 2>/dev/null || true
    chmod +x "$HOME/Desktop/Điệp Viên Study.app/Contents/MacOS/DiepVienStudy" 2>/dev/null || true
fi

echo ""
echo "=============================================================================="
echo "  🎉 CÀI ĐẶT HOÀN TẤT 100%! ĐANG MỞ 'ĐIỆP VIÊN STUDY' TRÊN MAC..."
echo "  Từ lần sau, bạn chỉ cần bấm vào icon 'Điệp Viên Study' trên Desktop"
echo "  hoặc trong Launchpad / Applications để dùng ngay!"
echo "=============================================================================="
if [ -d "/Applications/Điệp Viên Study.app" ]; then
    open "/Applications/Điệp Viên Study.app"
elif [ -d "$SCRIPT_DIR/Điệp Viên Study.app" ]; then
    open "$SCRIPT_DIR/Điệp Viên Study.app"
else
    cd "$SCRIPT_DIR" && nohup "$VENV_DIR/bin/python3" -X utf8 "$SCRIPT_DIR/DiepVienStudy.pyw" >/dev/null 2>&1 &
fi
sleep 2
exit 0
