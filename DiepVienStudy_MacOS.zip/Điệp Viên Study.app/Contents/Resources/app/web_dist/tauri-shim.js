// VietNote / VietLingua Tauri v2 Internals Shim
(function () {
  const params = new URLSearchParams(window.location.search);
  const currentLabel = params.get("window") || "main";

  let nextCallbackId = 1;
  const callbacks = new Map();
  const eventListeners = new Map(); // eventName -> Map<eventId, handlerCallbackId>

  function transformCallback(callback, once = false) {
    const id = nextCallbackId++;
    callbacks.set(id, { fn: callback, once: Boolean(once) });
    return id;
  }

  function unregisterCallback(id) {
    callbacks.delete(Number(id));
  }

  function runCallback(id, payload) {
    const entry = callbacks.get(Number(id));
    if (!entry) return;
    if (entry.once) {
      callbacks.delete(Number(id));
    }
    try {
      entry.fn(payload);
    } catch (err) {
      console.error("[TauriShim] Callback error:", err);
    }
  }

  function dispatchLocalEvent(eventName, payload) {
    const listeners = eventListeners.get(eventName);
    if (!listeners) return;
    for (const [eventId, handlerId] of listeners.entries()) {
      runCallback(handlerId, {
        event: eventName,
        id: eventId,
        payload: payload,
      });
    }
  }

  window.__TAURI_EVENT_PLUGIN_INTERNALS__ = {
    unregisterListener(event, eventId) {
      const listeners = eventListeners.get(event);
      if (listeners) {
        listeners.delete(eventId);
      }
    },
  };

  let audioCtx = null;
  let audioNextTime = 0;
  let activeSources = [];

  function handlePlayAudio(args) {
    const chunks = args.chunks || [];
    const rate = Number(args.rate) || 1.0;
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return 0;
    if (!audioCtx) {
      audioCtx = new AudioContextClass();
    }
    if (audioCtx.state === "suspended") {
      audioCtx.resume().catch(() => {});
    }
    const now = audioCtx.currentTime;
    if (audioNextTime < now) {
      audioNextTime = now;
    }
    for (const ch of chunks) {
      if (!ch || !ch.pcm) continue;
      const bin = atob(ch.pcm);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) {
        bytes[i] = bin.charCodeAt(i);
      }
      const floats = new Float32Array(bytes.buffer);
      const sr = Number(ch.sampleRate || ch.sample_rate) || 24000;
      const buf = audioCtx.createBuffer(1, floats.length, sr);
      buf.getChannelData(0).set(floats);
      const src = audioCtx.createBufferSource();
      src.buffer = buf;
      src.playbackRate.value = rate;
      src.connect(audioCtx.destination);
      src.start(audioNextTime);
      activeSources.push(src);
      src.onended = () => {
        const idx = activeSources.indexOf(src);
        if (idx >= 0) activeSources.splice(idx, 1);
      };
      audioNextTime += floats.length / sr / rate;
    }
    return Math.max(0, audioNextTime - now);
  }

  function handleStopAudio() {
    for (const s of activeSources) {
      try {
        s.stop();
      } catch (_e) {}
    }
    activeSources = [];
    if (audioCtx) {
      audioNextTime = audioCtx.currentTime;
    }
    return null;
  }

  window.__TAURI_INTERNALS__ = {
    metadata: {
      currentWindow: { label: currentLabel },
      currentWebview: { label: currentLabel },
      windows: [{ label: "main" }, { label: "island" }],
      webviews: [
        { windowLabel: "main", label: "main" },
        { windowLabel: "island", label: "island" },
      ],
    },
    transformCallback,
    unregisterCallback,
    convertFileSrc(filePath, protocol = "asset") {
      if (!filePath) return "";
      if (/^https?:\/\//i.test(filePath) || /^blob:/i.test(filePath) || /^data:/i.test(filePath)) {
        return filePath;
      }
      return `${window.location.origin}/__asset__?path=${encodeURIComponent(filePath)}`;
    },
    async invoke(cmd, args = {}, _options) {
      // 1. Event plugin commands
      if (cmd === "plugin:event|listen") {
        const eventName = args.event;
        const handlerId = args.handler;
        if (!eventListeners.has(eventName)) {
          eventListeners.set(eventName, new Map());
        }
        eventListeners.get(eventName).set(handlerId, handlerId);
        return handlerId;
      }
      if (cmd === "plugin:event|unlisten") {
        const listeners = eventListeners.get(args.event);
        if (listeners) {
          listeners.delete(args.eventId);
        }
        return null;
      }
      if (cmd === "plugin:event|emit" || cmd === "plugin:event|emit_to") {
        const targetLabel =
          cmd === "plugin:event|emit_to"
            ? typeof args.target === "string"
              ? args.target
              : args.target?.label
            : null;
        if (!targetLabel || targetLabel === currentLabel) {
          dispatchLocalEvent(args.event, args.payload);
        }
        // Forward to backend so the other window (main <-> island) also receives it
        try {
          await fetch("/__tauri_invoke__", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ cmd, args, window: currentLabel }),
          });
        } catch (_e) {}
        return null;
      }

      // 2. Audio playback & Updater & Window fast-path commands
      if (cmd === "play_audio") {
        return handlePlayAudio(args);
      }
      if (cmd === "stop_audio") {
        return handleStopAudio();
      }
      if (cmd === "plugin:updater|check") {
        return null;
      }
      if (cmd === "plugin:resources|close") {
        return null;
      }
      if (cmd.startsWith("plugin:window|") || cmd.startsWith("plugin:webview|")) {
        try {
          const resp = await fetch("/__tauri_invoke__", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ cmd, args, window: currentLabel }),
          });
          const data = await resp.json();
          return data.result ?? null;
        } catch (_e) {
          return null;
        }
      }

      // 3. Standard Backend Commands
      const resp = await fetch("/__tauri_invoke__", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cmd, args, window: currentLabel }),
      });
      const data = await resp.json();
      if (!data.ok) {
        throw new Error(data.error || `Command ${cmd} failed`);
      }
      return data.result;
    },
  };

  // Connect Server-Sent Events stream from local Python backend
  function connectEventStream() {
    const es = new EventSource(`/__tauri_events__?window=${encodeURIComponent(currentLabel)}`);
    es.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.kind === "event") {
          dispatchLocalEvent(msg.event, msg.payload);
        } else if (msg.kind === "channel") {
          const chPayload = { index: msg.index };
          if (msg.end) {
            chPayload.end = true;
          } else {
            chPayload.message = msg.message;
          }
          runCallback(msg.channelId, chPayload);
        }
      } catch (err) {
        console.error("[TauriShim] SSE parse error:", err);
      }
    };
    es.onerror = () => {
      es.close();
      setTimeout(connectEventStream, 1000);
    };
  }

  connectEventStream();

  // Notify window focus/blur events to Tauri window listeners
  window.addEventListener("focus", () => {
    dispatchLocalEvent("tauri://focus", true);
  });
  window.addEventListener("blur", () => {
    dispatchLocalEvent("tauri://blur", false);
  });
})();
